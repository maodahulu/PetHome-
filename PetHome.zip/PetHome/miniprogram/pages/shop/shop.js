// pages/shop/shop.js
const app = getApp()
Page({


  data: {
    background: [],
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 2000,
    duration: 500,
    navbar:[],
    currentTab:0,
    shopList:[],
    isDark:false
  },

  onLoad: function (options) {
    console.log(app.globalData);
    this.getBackground();
    this.getNavbarName();
    this.getShopList();
    this.setData({
      isDark:app.globalData.isDark
    });
    console.log(app.globalData)
  },
  // 获取轮播图
  getBackground:function(){
    wx.cloud.callFunction({
      name:"shop_background",
    }).then(res=>{
      console.log(res)
      this.setData({
        background:res.result.data
      })
    })
  },
  // 获取商城里的分类栏
  getNavbarName:function(){
    wx.cloud.callFunction({
      name:"shop_navbar",
    }).then(res=>{
      this.setData({
        navbar:res.result.data
      })
    })
  },
  //商品分栏点击事件
  navbarTap:function(e){
    console.log(e)
    this.setData({
      currentTab:e.currentTarget.dataset.idx
    })
  },

  getShopList:function(){
    wx.cloud.callFunction({
      name:"shop_list",
    }).then(res=>{
      this.setData({
        shopList:res.result.data
      })
    })
  },
  onShow:function(){
    this.onLoad()
  }


})