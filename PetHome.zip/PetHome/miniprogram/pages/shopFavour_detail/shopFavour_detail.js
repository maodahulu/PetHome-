// pages/shopFavour_detail/shopFavour_detail.js
const app = getApp()
let id,index;
Page({
  data: {
    detail:{},
    isDark:false
  },

  onLoad: function (options) {
    id = options.id;
    console.log(id)
    index = options.index;
    this.getDetail();
    this.setData({
      isDark:app.globalData.isDark
    })
  },

  getDetail:function(){
    wx.cloud.callFunction({
      name:"shopFavour_list_get_one",
      data:{
        id
      }
    }).then(res=>{
      this.setData({
        detail:res.result.data
      })
    })
  },

  removeFavour:function(){
    wx.cloud.callFunction({
      name:"shopFavour_remove",
      data:{
        id
      }
    }).then(res=>{
      wx.switchTab({
        url: '../shopFavour/shopFavour'
      })
    })
  },

})