const app = getApp()
Page({


  data: {
    userInfo:'',
    show:true,
    isDark:false
  },

  onLoad: function (options) {
    // console.log(app.globalData)
    this.setData({
      // userInfo:app.globalData.userInfo,
      show:app.globalData.show,
      isDark:app.globalData.isDark
    })
  },
  onShow:function(){
    console.log(app.globalData)
    this.setData({
      userInfo:app.globalData.userInfo,
    })
  },

login:function(){
  var that = this;
  wx.getUserProfile({
    desc: '用于信息完善',
    success(res){
      console.log(res.userInfo)
      var user = res.userInfo
      app.globalData.userInfo = user
       //获取用户的openid
      wx.cloud.callFunction({
        name:'obtainOpenid',
        success(result){
          console.log(11,result)
          app.globalData.openid = result.result.openid
        }, 
      })
      that.setData({
        userInfo:user,
        show:false
      })

      //需要检查之前用户是否登陆过
      wx.cloud.database().collection('login_users').where({
        _openid:app.globalData.openid
      }).get({
        success(res){
          if(res.data.length==0){
            wx.cloud.database().collection('login_users').add({
              data:{
                avatarUrl:user.avatarUrl,
                nickName: user.nickName
              },
              success(res){
                that.setData({
                  show:false
                })
                console.log(res)
                wx.showToast({
                  title: '登陆成功',
                })
              }
            })
          }else if(res.data[0].avatarUrl!=user.avatarUrl ||res.data[0].nickName!=user.nickName){
            wx.cloud.database().collection('login_users').where({
              _openid:app.globalData.openid
            }).update({
              data:{
                avatarUrl:user.avatarUrl,
                nickName: user.nickName
              },
              success(res){
                that.setData({
                  show:false
                })
                console.log(res)
                wx.showToast({
                  title: '登陆成功',
                })
              }
            })
          }
          else{
        that.setData({
          userInfo:res.data[0]
        })  
      }
    }
  })
    }
  })
},

  //下方功能
  contact:function(){
    wx.showModal({
      title:'提示',
      content:'请联系QQ：592031765',
    })
  },
  version:function(){
    wx.showToast({
      title: '已经是最新版本',
      duration:2000
    })
  },
  quit:function(){
    wx.clearStorageSync();
    app.globalData.openid = null;
    app.globalData.userInfo = null;
    wx.showToast({
      title: '已清除缓存',
      duration:2000,
      success:function(){
        setTimeout(function(){
          wx.reLaunch({
            url: '/pages/index/index',
          })
        },2000)
      }
    })
  },
  
  night:function(){
    var that = this;
    if(that.data.isDark){
      that.setData({
        isDark:false
      })
      app.globalData.isDark = false
    }else{
      that.setData({
        isDark:true
      })
      app.globalData.isDark = true
    }
  }
})