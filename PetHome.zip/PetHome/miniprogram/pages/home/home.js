const app = getApp()
Page({

  data: {
    background:[],
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 2000,
    duration: 500,
    list:[],
    isDark:false
  },

  onLoad: function (options) {
    this.getBackground();
    this.getList();
    this.setData({
      isDark:app.globalData.isDark
    })
  },
  // 获取轮播图
  getBackground:function(){
    wx.cloud.callFunction({
      name:"home_background"
    }).then(res=>{
      console.log(res)
      this.setData({
        background:res.result.data
      })
    })
  },

  //添加新内容跳转事件
  addInfo:function(){
    wx.navigateTo({
      url: '../homeAdd_detail/homeAdd_detail',
    })
  },

  // 获取动物内容
  getList:function () {
    wx.cloud.callFunction({
      name:"home_list_get"
    }).then(res=>{
      this.setData({
        list:res.result.data
      })
    })
  },

  onShow:function(){
    var that = this;
    that.setData({
      list:[]
    })
    this.onLoad(); //重新加载onLoad()
  },

})