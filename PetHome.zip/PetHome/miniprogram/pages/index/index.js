import common from "../../util/common";
const app = getApp()
Page({


  data: {
    listArr:[],
    loading:true,
    isDark:false
  },

  onLoad: function (options) {
      this.getData();
      this.setData({
        isDark:app.globalData.isDark
      })
  },
  
  getData(size=0){
    wx.cloud.callFunction({
      name:"article_list_get",
      data:{
        size
      }
    }).then(res=>{
      res.result.data.forEach(item=>{
        let hits= item.hits?item.hits:0
        item.hits=common.getNumber(hits);
        item._createTime=common.getTime(item._createTime,4)
      })

      if(res.result.data<=0){
        this.setData({
          loading:false
        })
      }
      let oldData=this.data.listArr;
      let newData=oldData.concat(res.result.data)
      this.setData({
        listArr:newData
      })
    })
  },
  // 页面下拉触底事件的处理函数
  onReachBottom:function(){ 
    this.getData(this.data.listArr.length)
  },

  onShow:function(){
    var that = this;
    that.setData({
      listArr:[]
    })
    this.onLoad(); //重新加载onLoad()
  }

})

