// pages/shoppingCart/shoppingCart.js
const app = getApp()
Page({

  data: {
    shopFavourList:[],
    isDark:false
  },

  onLoad: function (options) {
    this.getShopFavourList();
    wx.stopPullDownRefresh();
    this.setData({
      isDark:app.globalData.isDark
    })
  },

  getShopFavourList:function(){
    if(app.globalData.openid)
    wx.cloud.callFunction({
      name:"shop_favour_list"
    }).then(res=>{
      console.log(res)
      this.setData({
        shopFavourList:res.result.data
      })
    })

    },


    onPullDownRefresh: function () {
      var that = this;
      that.setData({
        shopFavourList:[]//当前页的一些初始数据，视业务需求而定
      })
      this.onLoad(); //重新加载onLoad()
    },

    // 页面切换时刷新
    onShow:function(){
      var that = this;
      that.setData({
        shopFavourList:[]//当前页的一些初始数据，视业务需求而定
      })
      this.onLoad(); //重新加载onLoad()
    }
  

})