// pages/shop_detail/shop_detail.js
const app = getApp()
let id,index;
Page({


  data: {
    detail:{},
    isDark:false
  },

  onLoad: function (options) {
    id = options.id;
    console.log(id)
    index = options.index;
    console.log(index)
    this.getDetail();
    this.setData({
      isDark:app.globalData.isDark
    })
  },

  getDetail:function(){
    wx.cloud.callFunction({
      name:"shop_list_get_one",
      data:{
        id
      }
    }).then(res=>{
      this.setData({
        detail:res.result.data
      })
    })
  },

  clickFavour:function(){
    let onfavour = this.data.detail.onfavour;
    this.setData({
      "detail.onfavour":!onfavour
    })
    let Id = this.data.detail._id;
    let Name = this.data.detail.name;
    let Price = this.data.detail.price;
    let Image = this.data.detail.image;
    let Content = this.data.detail.content;
    let Word = this.data.detail.word;
    wx.cloud.callFunction({
      name:"shop_favour",
      data:{
        Id:Id,
        Name:Name,
        Price:Price,
        Image:Image,
        Content:Content,
        Word:Word
      }
    }).then(res=>{
      console.log(res)
    })
  },

  // textPaste:function(e){
  //   wx.showToast({
  //     title: '复制成功',
  //   })
  //   wx.setClipboardData({
  //     data:this.data.detail.word,
  //     success: function (res) {
  //       wx.getClipboardData({    //这个api是把拿到的数据放到电脑系统中的
  //       }).then(res=>{
  //         console.log(res.data)
  //       })
  //     }
  //   })
  // },
  
  
 
  
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})