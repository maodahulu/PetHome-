// pages/home_detail/home_detail.js
import common from "../../util/common";
let app =getApp();
let id,index;
Page({


  data: {
    detail:[],
    commentList:[],
    commentid:'',
    openid:'',
    isDark:false,
    comment:'',
		info: "",
  },

  onLoad:function(e){
    id = e.id || e;
    index= e.index;
    this.getInfo();
    this.getComment();
    this.setData({
      isDark:app.globalData.isDark
    })
  },

  onShow(){
    this.onLoad(id)
  },

  // 获取动物信息
  getInfo:function(){
    wx.cloud.callFunction({
      name:"home_list_get_one",
      data:{
        id
      }
    }).then(res=>{
      console.log(res)
      this.setData({
        detail:res.result.data,
        openid:app.globalData.openid
      })
    })
  },



  // 提交评论内容到数据库
  submit:function () {
    let posttime=Date.now();
    let content = this.data.comment;
    let comment = this.data.comment;
    var that = this;
    that.setData({         
      info: ''     
    })
    if(this.data.openid){
      if(comment){
        wx.cloud.callFunction({
          name:"home_detail_comment",
          data:{
            nickName:app.globalData.userInfo.nickName,
            avatarUrl:app.globalData.userInfo.avatarUrl,
            posttime,
            id,
            content
          }
        }).then(res=>{
          wx.showToast({
            title: '提交成功',
          })
          this.onLoad(id);
        })
      }else{
        wx.showToast({
          title: '提交内容为空',
        })
      }
    }else{
      wx.showToast({
        title: '请登录',
      })
    }

  },

  // 获取评论区内容
  getComment:function(){
    wx.cloud.callFunction({
      name:"home_detail_comment_get",
      data:{
        id
      }
    }).then(res=>{
      let item = res.result.data;
      console.log(item);
      for(let i =0; i<item.length;i++){
        item[i].posttime = common.getTime(item[i].posttime,4);
      }
      this.setData({
        commentList: item
      })
      
    })
  },
// 删除帖子功能(只有发帖用户才能删除自己的帖子)
  remove:function(){
    wx.showModal({
      title:'提示',
      content:'请问是否删除帖子',
      success:function(res){
        if(res.confirm){
          wx.cloud.callFunction({
            name:"home_list_remove",
            data:{
              id
            }
          })
          wx.showToast({
            title: '删除成功',
          }).then(res=>{
            wx.switchTab({
              url: '../home/home',
            })
          })
        }else if(res.cancel){
          wx.showToast({
            title: '取消删除',
          })
        }
      }
    })
    
  },

  // 删除评论功能(只有评论用户才能删除自己的评论)
  removeComment:function(e){
    this.data.commentid = e.currentTarget.dataset.cid;
    var that = this;
    wx.showModal({
      title:'提示',
      content:'请问是否删除评论',
      success:function(res){
        if(res.confirm){
          wx.cloud.callFunction({
            name:"home_detail_comment_remove",
            data:{
              id:that.data.commentid
            }
          })
          wx.showToast({
            title: '删除成功',
          }).then(res=>{
            that.onShow()
          })
        }else if(res.cancel){
          wx.showToast({
            title: '取消删除',
          })
        }
      }
    })

  },

})