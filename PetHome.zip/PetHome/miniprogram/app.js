//app.js
App({
  onLaunch() {
    //云环境开发初始化
    wx.cloud.init({
      env:"cloud1-6gs5w1mk22758745"
    })

    //获取用户的openid
    var that = this;
    wx.cloud.callFunction({
      name:'obtainOpenid',
      success(res){
        console.log(11,res)
        that.globalData.openid = res.result.openid

      //查找数据库用户表里是否有这个用户记录
      wx.cloud.database().collection('login_users').where({
        _openid:res.result.openid
      }).get({
        success(result){
          console.log(12,result)
          that.globalData.userInfo = result.data[0]
          console.log(that.globalData.userInfo)
        }
      })
      },
      fail(){
        console.log('000')
      }
    })
    },
    globalData:{
      userInfo:null,
      openid:null,
      show:true,
      isDark:false
    },
  
})
