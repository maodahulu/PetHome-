// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:"cloud1-6gs5w1mk22758745"
})
const db = cloud.database();

// 云函数入口函数
exports.main = async (event, context) => {
  let size = event.size;
  let res =  await db.collection("article_list").orderBy("_createTime","desc")
  .limit(7)
  .skip(size)
  .get();
  
  for(let i=0;i<res.data.length;i++){
    let count = await db.collection("article_like").where({
      artid:res.data[i]._id
    }).count();
    res.data[i].zanSize = count.total
  }
  return res;
}